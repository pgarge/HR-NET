package com.hracuity.quotes.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.hracuity.quotes.exception.ResourceNotFoundException;
import com.hracuity.quotes.model.QuoteEntity;
import com.hracuity.quotes.repository.QuoteRepository;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import java.util.Optional;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@ExtendWith(MockitoExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class QuoteServiceIntegrationTest {

	@Autowired
	private QuoteRepository quoteRepository;

	@Autowired
	private QuoteService quoteService;

	@BeforeEach
	public void setup() {
		// Clear the database before each test
		quoteRepository.deleteAll();
	}

	@AfterEach
	public void cleanup() {
	}

	@Test
	public void testAddQuotes() {
		// Prepare test data
		List<QuoteEntity> quotes = new ArrayList<>();
		quotes.add(new QuoteEntity(0, "Author 1", "Quote 1"));
		quotes.add(new QuoteEntity(1, "Author 2", "Quote 2"));
		quotes.add(new QuoteEntity(2, "Author 3", "Quote 3"));

		// Execute the method
		quoteService.addQuotes(quotes);

		// Verify that the entities were saved to the database
		List<QuoteEntity> savedQuotes = quoteRepository.findAll();
		assertEquals(3, savedQuotes.size());
	}

	@Test
	public void testDeleteQuote() {
		// Given
		QuoteEntity quoteEntity = new QuoteEntity(4, "Author 4", "Quote 4");
		quoteRepository.save(quoteEntity);
		// When
		quoteService.deleteQuote(4l);

		// Then
		assertFalse(quoteRepository.existsById(4l));
	}

	@Test
	public void testUpdateQuote() {
		// Given
		QuoteEntity quoteEntity = new QuoteEntity(5, "Author 5", "Quote 5");
		quoteRepository.save(quoteEntity);

		QuoteEntity updatedQuote = new QuoteEntity(5, "Author new 5", "Quote 5 new");


		// When
		quoteService.updateQuote(5l, updatedQuote);

		// Then
		Optional<QuoteEntity> retrievedQuoteOptional = quoteRepository.findById(5l);
		assertTrue(retrievedQuoteOptional.isPresent());
		assertEquals("Quote 5 new", retrievedQuoteOptional.get().getText());
	}

	@Test
	public void testGetQuote() {
		// Given
		QuoteEntity quoteEntity = new QuoteEntity(6, "Author 6", "Quote 6");
		quoteRepository.save(quoteEntity);

		// When
		QuoteEntity retrievedQuote = quoteService.getQuote(6l);

		// Then
		assertNotNull(retrievedQuote);
		assertEquals("Quote 6", retrievedQuote.getText());
	}

	@Test
	public void testGetQuoteNotFound() {
		// Given
		Long nonExistentId = 999L;

		// When / Then
		assertThrows(ResourceNotFoundException.class, () -> quoteService.getQuote(nonExistentId));
	}

	@Test
	public void testGetPairCount() {
		List<QuoteEntity> quotes = Arrays.asList(

			new QuoteEntity(0, "Avin Fernando", "Hello, World!"),
			new QuoteEntity(1, "Gaius Julius Caesar", "Veni, Vidi, Vici"),
			new QuoteEntity(2, "Renee Descartes", "Cogito, ergo sum"),
			new QuoteEntity(3, "Jesus", "Do unto others as you would have them do unto you"),
			new QuoteEntity(4, "AzureDiamond", "hunter2"),
			new QuoteEntity(5, "Isaac Newton", "To every action there is always opposed an equal reaction"),
			new QuoteEntity(6, "Yoda", "Do, or do not. There is no try.")
		);
		quoteRepository.saveAll(quotes);
		int result1 = quoteService.getPairCount(19);
		int result2 = quoteService.getPairCount(22);
		int result3 = quoteService.getPairCount(32);
		int result4 = quoteService.getPairCount(40);
		int result5 = quoteService.getPairCount(200);

		// Verify that the actual pair count matches the expected pair count
		Assertions.assertEquals(0, result1);
		Assertions.assertEquals(1, result2);
		Assertions.assertEquals(6, result3);
		Assertions.assertEquals(7, result4);
		Assertions.assertEquals(21, result5);
	}
}

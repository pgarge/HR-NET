package com.hracuity.quotes.service;

import com.hracuity.quotes.exception.ResourceNotFoundException;
import com.hracuity.quotes.model.QuoteEntity;
import com.hracuity.quotes.repository.QuoteRepository;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class QuoteService {

	private QuoteRepository quoteRepository;

	@Autowired
	public QuoteService(QuoteRepository quoteRepository) {
		this.quoteRepository = quoteRepository;
	}

	@Transactional
	public void addQuotes(List<QuoteEntity> quotes) {
		int numThreads = Runtime.getRuntime().availableProcessors();

		// Create a thread pool with the specified number of threads
		ExecutorService executorService = Executors.newFixedThreadPool(numThreads);

		// Calculate the chunk size for dividing the list
		int chunkSize = (int) Math.ceil((double) quotes.size() / numThreads);

		// Submit tasks to the thread pool for parallel processing
		for (int i = 0; i < quotes.size(); i += chunkSize) {
			int endIndex = Math.min(i + chunkSize, quotes.size());
			List<QuoteEntity> chunk = quotes.subList(i, endIndex);
			executorService.submit(() -> quoteRepository.saveAll(chunk));
		}

		// Shutdown the thread pool and wait for all tasks to complete
		executorService.shutdown();
		try {
			executorService.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}

	public void deleteQuote(Long id) {
		quoteRepository.deleteById(id);
	}

	public void updateQuote(Long id, QuoteEntity updatedQuote)  {
		// Fetch the existing quote by id
		Optional<QuoteEntity> existingQuoteOptional = quoteRepository.findById(id);
		if (existingQuoteOptional.isPresent()) {
			QuoteEntity existingQuote = existingQuoteOptional.get();
			// Update the existing quote with the new data
			existingQuote.setText(updatedQuote.getText());
			// Save the updated quote
			quoteRepository.save(existingQuote);
		} else {
			throw new ResourceNotFoundException("Quote not found with id: " + id);
		}
	}

	public QuoteEntity getQuote(Long id) {
		return quoteRepository.findById(id)
			.orElseThrow(() -> new ResourceNotFoundException("Quote not found with id: " + id));
	}

	// I came up with 3 solutions. The first one involves comparing every element, which is O(n^2).
	// The second approach is processing the objects in parallel to save time with large datasets, as there are many quotes.
	// The third solution has a better complexity of O(n log n) by using sorting.
	public int getPairCount(int maxLength) {
    	List<QuoteEntity> allQuotes = getAllQuotes();
		// Approach 1
//		int count = 0;
//		for (int i = 0; i < allQuotes.size(); i++) {
//			for (int j = i + 1; j < allQuotes.size(); j++) {
//				QuoteEntity firstQuote = allQuotes.get(i);
//				QuoteEntity secondQuote = allQuotes.get(j);
//				// Check if the sum of text lengths of both quotes is less than or equal to maxLength
//				if (firstQuote.getText().length() + secondQuote.getText().length() <= maxLength) {
//					// Increment the count if the pair satisfies the condition
//					count++;
//				}
//			}
//		}
//
//		return count;

		// Approach 2
//		Set<String> uniquePairs = ConcurrentHashMap.newKeySet();
//
//		// Counter for counting pairs
//		AtomicInteger pairCount = new AtomicInteger();
//
//		// Perform parallel processing to count pairs
//		allQuotes.parallelStream().forEach(quote1 ->
//			allQuotes.stream()
//				.skip(allQuotes.indexOf(quote1) + 1) // Skip quotes before quote1
//				.forEach(quote2 -> {
//					if (quote1.getText().length() + quote2.getText().length() <= maxLength) {
//						// Construct pair key ensuring the same order of quotes regardless of sequence
//						String pairKey = quote1.getId() < quote2.getId() ?
//							quote1.getText() + " - " + quote2.getText() :
//							quote2.getText() + " - " + quote1.getText();
//						// Add the pair to the ConcurrentHashMap only if absent
//						uniquePairs.add(pairKey);
//						// Increment the pair count
//						pairCount.incrementAndGet();
//					}
//				}));
//
//		return pairCount.get();

		// Approach 3
		allQuotes.sort(Comparator.comparingInt(q -> q.getText().length()));

		int left = 0;
		int right = allQuotes.size() - 1;
		int count = 0;

		while (left < right) {
			int combinedLength = allQuotes.get(left).getText().length() + allQuotes.get(right).getText().length();
			if (combinedLength <= maxLength) {
				// Increment count by the number of valid pairs between left and right
				count += right - left;
				// Move left pointer to the right to find more valid pairs
				left++;
			} else {
				// Decrement right pointer to reduce combined length
				right--;
			}
		}

		return count;
	}

	public List<QuoteEntity> getAllQuotes() {
		return quoteRepository.findAll();
	}
}

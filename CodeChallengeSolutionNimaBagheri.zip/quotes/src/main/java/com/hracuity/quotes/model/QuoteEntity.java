package com.hracuity.quotes.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity(name = "quote")
public class QuoteEntity {

  @Id
  @JsonProperty("Id")
  private long id;

  @JsonProperty("Author")
  private String author;

  @JsonProperty("Text")
  private String text;
}

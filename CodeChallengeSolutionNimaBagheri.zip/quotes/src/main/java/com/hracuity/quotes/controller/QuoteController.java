package com.hracuity.quotes.controller;

import com.hracuity.quotes.model.QuoteEntity;
import com.hracuity.quotes.service.QuoteService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/quotes")
public class QuoteController {

	private QuoteService quoteService;

	@Autowired
	public QuoteController(QuoteService quoteService) {
		this.quoteService = quoteService;
	}

	@GetMapping
	public ResponseEntity<List<QuoteEntity>> getAllQuotes() {
		// Ideally, this needs to be paginated, but for now, I have only implemented retrieving all the quotes.
		return ResponseEntity.ok(quoteService.getAllQuotes());
	}

	@PostMapping
	public ResponseEntity<String> addQuotes(@RequestBody List<QuoteEntity> quotes) {
		quoteService.addQuotes(quotes);
		return ResponseEntity.ok("Quote added successfully");
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteQuote(@PathVariable Long id) {
		quoteService.deleteQuote(id);
		return ResponseEntity.ok("Quote deleted successfully");
	}

	@PutMapping("/{id}")
	public ResponseEntity<String> updateQuote(@PathVariable Long id, @RequestBody QuoteEntity quote) {
		quoteService.updateQuote(id, quote);
		return ResponseEntity.ok("Quote updated successfully");
	}

	@GetMapping("/{id}")
	public ResponseEntity<QuoteEntity> getQuote(@PathVariable Long id) {
		QuoteEntity quote = quoteService.getQuote(id);
		return ResponseEntity.ok(quote);
	}

	@GetMapping("/pair-count/{maxLength}")
	public ResponseEntity<Integer> getPairCount(@PathVariable int maxLength) {
		return ResponseEntity.ok(quoteService.getPairCount(maxLength));
	}
}
